################################################################################
## combine_results.R
##
## Run after all 32 tasks finish:
##   Rscript scripts/combine_results.R
##
## Output: results/supplementary_null_results.rds and .csv
################################################################################

files <- list.files("results", pattern = "^task_\\d+\\.rds$", full.names = TRUE)
cat("Found", length(files), "of 32 task results\n")

tab <- do.call(rbind, lapply(files, function(f) readRDS(f)$summary))
tab <- tab[order(tab$task_id), ]

missing <- setdiff(1:32, tab$task_id)
if (length(missing) > 0) cat("Missing tasks:", paste(missing, collapse = ", "), "\n")

saveRDS(tab, "results/supplementary_null_results.rds")
write.csv(tab, "results/supplementary_null_results.csv", row.names = FALSE)

cat("\n--- MEAN SHIFT (Var(theta_T2) = 1) ---\n")
print(subset(tab, condition_type == "Mean shift",
             c(n_items, n, mean_t2, type1_grmtree, type1_lrt)), row.names = FALSE)

cat("\n--- VARIANCE HETEROGENEITY (mu_T2 = 0) ---\n")
print(subset(tab, condition_type == "Variance heterogeneity",
             c(n_items, n, var_t2, type1_grmtree, type1_lrt)), row.names = FALSE)
