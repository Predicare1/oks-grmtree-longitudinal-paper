################################################################################
## sim_supp_null_run.R
##
## Runs ONE cell of the supplementary null simulation (both GRMTree and LRT
## on the same simulated datasets).
##
## Usage (from the project folder):
##   Rscript scripts/sim_supp_null_run.R <TASK_ID>      # TASK_ID in 1..32
##
## Output:      results/task_XX.rds
## Checkpoint:  checkpoints/task_XX.rds (saved every 25 reps; job resumes
##              from it automatically if resubmitted)
################################################################################

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1) stop("Usage: Rscript scripts/sim_supp_null_run.R <TASK_ID>")
task_id <- as.integer(args[1])

source("sim_supp_null_functions.R")

grid <- get_sim_grid()
if (!(task_id %in% grid$task_id)) stop("TASK_ID must be between 1 and ", nrow(grid))
cond <- grid[task_id, ]

n_reps    <- 500
ckpt_file <- sprintf("checkpoints/task_%02d.rds", task_id)
out_file  <- sprintf("results/task_%02d.rds", task_id)

cat("============================================================\n")
cat("SUPPLEMENTARY NULL SIMULATION | task", task_id, "\n")
cat("Condition:", cond$condition_type,
    "| items =", cond$n_items, "| n =", cond$n,
    "| mu_T2 =", cond$mean_t2, "| Var(theta_T2) =", cond$var_t2,
    "| rho =", cond$rho, "\n")
cat("============================================================\n")

## Resume from checkpoint if available, otherwise start fresh
if (file.exists(ckpt_file)) {
  ck <- readRDS(ckpt_file)
  grm_res <- ck$grm_res; lrt_res <- ck$lrt_res; start_rep <- ck$last_rep + 1
  assign(".Random.seed", ck$seed, envir = .GlobalEnv)
  cat("Resuming from rep", start_rep, "\n")
} else {
  set.seed(2026 + task_id)
  grm_res <- rep(NA_real_, n_reps); lrt_res <- rep(NA_real_, n_reps); start_rep <- 1
}

specs <- build_lrt_specs(cond$n_items)
t0 <- Sys.time()

if (start_rep <= n_reps) {
  for (rep in start_rep:n_reps) {

    dat <- generate_data(cond$n, cond$n_items, cond$rho, cond$mean_t2, cond$var_t2)
    grm_res[rep] <- fit_grmtree_null(dat, cond$n_items, minbucket = 50)
    lrt_res[rep] <- fit_lrt_null(dat, cond$n_items, specs)

    if (rep %% 25 == 0 || rep == n_reps) {
      saveRDS(list(grm_res = grm_res, lrt_res = lrt_res, last_rep = rep,
                   seed = .Random.seed), ckpt_file)
      cat(format(Sys.time(), "%H:%M:%S"), "| rep", rep, "/", n_reps,
          "| GRMTree so far:", round(100 * mean(grm_res[1:rep], na.rm = TRUE), 1), "%",
          "| LRT so far:",     round(100 * mean(lrt_res[1:rep], na.rm = TRUE), 1), "%\n")
    }
  }
}

result <- data.frame(
  task_id        = task_id,
  condition_type = cond$condition_type,
  n_items        = cond$n_items,
  n              = cond$n,
  rho            = cond$rho,
  mean_t2        = cond$mean_t2,
  var_t2         = cond$var_t2,
  n_valid_grm    = sum(!is.na(grm_res)),
  n_valid_lrt    = sum(!is.na(lrt_res)),
  type1_grmtree  = round(100 * mean(grm_res, na.rm = TRUE), 1),
  type1_lrt      = round(100 * mean(lrt_res, na.rm = TRUE), 1)
)

saveRDS(list(summary = result, grm_raw = grm_res, lrt_raw = lrt_res), out_file)

cat("------------------------------------------------------------\n")
print(result, row.names = FALSE)
cat("Saved:", out_file, "| runtime this session:",
    round(as.numeric(difftime(Sys.time(), t0, units = "hours")), 2), "hours\n")
