#!/bin/bash
# Usage: bash submit_all.sh ALL | A | B
#   A = mean-shift null conditions (tasks 1-16)
#   B = variance-heterogeneity null conditions (tasks 17-32)
GROUP=${1:-ALL}
mkdir -p logs results checkpoints

case $GROUP in
  A)   FILES=$(ls slurm_jobs/A*.slurm) ;;
  B)   FILES=$(ls slurm_jobs/B*.slurm) ;;
  ALL) FILES=$(ls slurm_jobs/*.slurm) ;;
  *)   echo "Usage: bash submit_all.sh ALL | A | B"; exit 1 ;;
esac

for f in $FILES; do
  echo "Submitting $f"
  sbatch "$f"
done
echo "Done. Check with: squeue -u \$USER"
