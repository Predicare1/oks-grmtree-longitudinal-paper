################################################################################
## sim_supp_null_functions.R
##
## Self-contained functions for the supplementary null simulation
## (impact and latent variance heterogeneity, no item-parameter change).
## Does not depend on any other script in the project.
##
## Authors: O. I. Arimoro, T. T. Sajobi, E. Bohm, L. M. Lix
################################################################################

suppressPackageStartupMessages({
  library(grmtree)
  library(mirt)
})

## ---------------------------------------------------------------------------
## Simulation grid: 32 tasks
##   Tasks  1-16: mean shift      (mu_T2 = 0.25, 0.50; Var(theta_T2) = 1)
##   Tasks 17-32: variance hetero (Var(theta_T2) = 0.5, 1.5; mu_T2 = 0)
##   Within each: n_items in {6, 12} x n in {200, 500, 750, 1500}
##   rho fixed at 0.6
## ---------------------------------------------------------------------------

get_sim_grid <- function() {
  dist_conds <- data.frame(
    condition_type = c("Mean shift", "Mean shift",
                       "Variance heterogeneity", "Variance heterogeneity"),
    mean_t2 = c(0.25, 0.50, 0.00, 0.00),
    var_t2  = c(1.00, 1.00, 0.50, 1.50)
  )
  grid <- expand.grid(n = c(200, 500, 750, 1500),
                      n_items = c(6, 12),
                      dist_row = 1:4)
  grid <- cbind(grid[, c("n_items", "n")], dist_conds[grid$dist_row, ])
  grid$rho <- 0.6
  grid$task_id <- seq_len(nrow(grid))
  rownames(grid) <- NULL
  grid
}

## ---------------------------------------------------------------------------
## Item parameters (identical at T1 and T2: null of invariance)
## Same values as the main simulation.
## ---------------------------------------------------------------------------

get_item_params <- function(n_items) {
  a12 <- c(1.2, 1.5, 1.1, 1.8, 1.3, 1.6, 1.4, 1.7, 1.2, 1.5, 1.3, 1.9)
  d12 <- matrix(c(
    2.0, 0.7, -0.7, -2.0,
    1.8, 0.5, -0.5, -1.8,
    2.2, 0.8, -0.6, -2.1,
    1.9, 0.6, -0.8, -1.9,
    2.1, 0.7, -0.5, -2.0,
    1.7, 0.4, -0.6, -1.7,
    2.0, 0.6, -0.7, -1.8,
    1.8, 0.5, -0.5, -1.9,
    2.2, 0.8, -0.6, -2.2,
    1.9, 0.6, -0.7, -1.8,
    2.0, 0.7, -0.8, -2.0,
    1.8, 0.5, -0.6, -1.7
  ), nrow = 12, ncol = 4, byrow = TRUE)
  list(a = a12[1:n_items], d = d12[1:n_items, , drop = FALSE])
}

## ---------------------------------------------------------------------------
## Correlated latent traits with configurable T2 mean and variance
##   theta_T1 ~ N(0, 1)
##   theta_T2 = rho*sigma*theta_T1 + sigma*sqrt(1 - rho^2)*eps + mu_T2
## gives Var(theta_T2) = var_t2 and Cor(theta_T1, theta_T2) = rho.
## ---------------------------------------------------------------------------

generate_theta <- function(n, rho, mean_t2 = 0, var_t2 = 1) {
  sigma <- sqrt(var_t2)
  theta_t1 <- rnorm(n)
  theta_t2 <- rho * sigma * theta_t1 + sigma * sqrt(1 - rho^2) * rnorm(n) + mean_t2
  list(t1 = theta_t1, t2 = theta_t2)
}

## ---------------------------------------------------------------------------
## Generate one dataset (wide T1/T2 response matrices)
## ---------------------------------------------------------------------------

generate_data <- function(n, n_items, rho, mean_t2, var_t2) {
  p <- get_item_params(n_items)
  th <- generate_theta(n, rho, mean_t2, var_t2)
  r1 <- simdata(a = p$a, d = p$d, N = n, itemtype = "graded",
                Theta = matrix(th$t1, ncol = 1))
  r2 <- simdata(a = p$a, d = p$d, N = n, itemtype = "graded",
                Theta = matrix(th$t2, ncol = 1))
  list(r1 = r1, r2 = r2)
}

## ---------------------------------------------------------------------------
## GRMTree on person-period data, time as sole covariate.
## Returns 1 if the tree splits on time (false positive), 0 otherwise, NA on error.
## ---------------------------------------------------------------------------

fit_grmtree_null <- function(dat, n_items, minbucket = 50) {
  item_names <- paste0("Item_", 1:n_items)
  n <- nrow(dat$r1)
  d1 <- as.data.frame(dat$r1); names(d1) <- item_names; d1$time <- "T1"
  d2 <- as.data.frame(dat$r2); names(d2) <- item_names; d2$time <- "T2"
  df <- rbind(d1, d2)
  df$time <- factor(df$time, levels = c("T1", "T2"))
  df$resp <- as.matrix(df[, item_names])

  tryCatch({
    tree <- grmtree(resp ~ time, data = df,
                    control = grmtree.control(minbucket = minbucket,
                                              p_adjust = "bonferroni",
                                              alpha = 0.05))
    as.numeric(length(nodeids(tree, terminal = TRUE)) > 1)
  }, error = function(e) NA_real_)
}

## ---------------------------------------------------------------------------
## LRT: two-factor longitudinal GRM (free T2 mean and T1-T2 covariance),
## item parameters constrained equal across time vs. freely estimated.
## Returns 1 if p < 0.05 (false positive), 0 otherwise, NA on error.
## ---------------------------------------------------------------------------

build_lrt_specs <- function(n_items) {
  t1 <- 1:n_items
  t2 <- (n_items + 1):(2 * n_items)
  a_con <- paste0("(", t1, ", a1, ", t2, ", a2)", collapse = ", ")
  d_con <- paste(sapply(1:4, function(k)
    paste0("(", t1, ",", t2, ", d", k, ")", collapse = ", ")), collapse = ", ")
  base <- paste0("Theta_T1 = 1-", n_items, "\n",
                 "Theta_T2 = ", n_items + 1, "-", 2 * n_items, "\n",
                 "COV = Theta_T1*Theta_T2\n",
                 "MEAN = Theta_T2")
  list(constrained   = paste0(base, "\nCONSTRAIN = ", a_con, ", ", d_con),
       unconstrained = base)
}

fit_lrt_null <- function(dat, n_items, specs) {
  r1 <- dat$r1; r2 <- dat$r2
  colnames(r1) <- paste0("T1_Item", 1:n_items)
  colnames(r2) <- paste0("T2_Item", 1:n_items)
  wide <- cbind(r1, r2)

  tryCatch({
    m0 <- mirt(wide, mirt.model(specs$constrained), itemtype = "graded",
               SE = FALSE, verbose = FALSE)
    m1 <- mirt(wide, mirt.model(specs$unconstrained), itemtype = "graded",
               SE = FALSE, verbose = FALSE)
    as.numeric(anova(m0, m1)$p[2] < 0.05)
  }, error = function(e) NA_real_)
}
