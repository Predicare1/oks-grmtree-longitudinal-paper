# Supplementary null simulation: impact and latent variance heterogeneity

Checks whether GRMTree (and the LRT) falsely flag longitudinal non-invariance when item parameters are identical across occasions but the latent trait distribution changes.

## Design (rho = 0.6, 500 reps per cell, GRMTree and LRT fitted to the same datasets)

| Jobs | Condition | mu_T2 | Var(theta_T2) |
|---|---|---|---|
| A01-A08 | Mean shift | 0.25 | 1.0 |
| A09-A16 | Mean shift | 0.50 | 1.0 |
| B01-B08 | Variance heterogeneity | 0 | 0.5 |
| B09-B16 | Variance heterogeneity | 0 | 1.5 |

Within each block of 8: jobs 1-4 = 6 items with N = 200, 500, 750, 1500; jobs 5-8 = 12 items with the same N.

## Run on ARC

```bash
tar xzf sim_supp_null.tar.gz
cd sim_supp_null
mkdir -p logs results checkpoints
bash submit_all.sh ALL        # or A / B
```

Jobs checkpoint every 25 reps. If a job is killed, resubmit the same `.slurm` file and it resumes.

When all 32 are done:

```bash
module load R/4.4.1
Rscript scripts/combine_results.R
```

Gives `results/supplementary_null_results.csv` (the response-letter table).

## Run locally

Any single cell: `Rscript scripts/sim_supp_null_run.R 9` (from this folder). Task IDs 1-32 follow the job order above.
