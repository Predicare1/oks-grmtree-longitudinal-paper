#!/bin/bash
# Usage: bash submit_all.sh ALL
mkdir -p logs results checkpoints
for f in slurm_jobs/B*.slurm; do
  echo "Submitting $f"
  sbatch "$f"
done
echo "Done. Check with: squeue -u \$USER"
