################################################################################
## sim_supp_null_B_lrt_run.R
##
## Runs ONE variance-heterogeneity cell (task 17-32), LRT only, with the T2
## variance freed in the constrained model.
##
## Usage (from the project folder):
##   Rscript scripts/sim_supp_null_B_lrt_run.R <TASK_ID>     # 17..32
##
## Output:      results/taskB_XX.rds
## Checkpoint:  checkpoints/taskB_XX.rds (every 25 reps; resumes if resubmitted)
################################################################################

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1) stop("Usage: Rscript scripts/sim_supp_null_B_lrt_run.R <TASK_ID>")
task_id <- as.integer(args[1])
if (!(task_id %in% 17:32)) stop("TASK_ID must be between 17 and 32")

source("sim_supp_null_B_lrt_functions.R")

cond      <- get_sim_grid()[task_id, ]
n_reps    <- 500
ckpt_file <- sprintf("checkpoints/taskB_%02d.rds", task_id)
out_file  <- sprintf("results/taskB_%02d.rds", task_id)

cat("============================================================\n")
cat("B RERUN: LRT WITH FREE T2 VARIANCE | task", task_id, "\n")
cat("items =", cond$n_items, "| n =", cond$n,
    "| Var(theta_T2) =", cond$var_t2, "| rho =", cond$rho, "\n")
cat("============================================================\n")

if (file.exists(ckpt_file)) {
  ck <- readRDS(ckpt_file)
  lrt_res <- ck$lrt_res; start_rep <- ck$last_rep + 1
  assign(".Random.seed", ck$seed, envir = .GlobalEnv)
  cat("Resuming from rep", start_rep, "\n")
} else {
  set.seed(2026 + task_id)
  lrt_res <- rep(NA_real_, n_reps); start_rep <- 1
}

specs <- build_lrt_specs_freevar(cond$n_items)
t0 <- Sys.time()

if (start_rep <= n_reps) {
  for (rep in start_rep:n_reps) {
    dat <- generate_data(cond$n, cond$n_items, cond$rho, cond$mean_t2, cond$var_t2)
    lrt_res[rep] <- fit_lrt_freevar(dat, cond$n_items, specs)

    if (rep %% 25 == 0 || rep == n_reps) {
      saveRDS(list(lrt_res = lrt_res, last_rep = rep, seed = .Random.seed), ckpt_file)
      cat(format(Sys.time(), "%H:%M:%S"), "| rep", rep, "/", n_reps,
          "| LRT (free variance) so far:",
          round(100 * mean(lrt_res[1:rep], na.rm = TRUE), 1), "%\n")
    }
  }
}

result <- data.frame(
  task_id             = task_id,
  n_items             = cond$n_items,
  n                   = cond$n,
  var_t2              = cond$var_t2,
  n_valid_lrt         = sum(!is.na(lrt_res)),
  type1_lrt_freevar   = round(100 * mean(lrt_res, na.rm = TRUE), 1)
)

saveRDS(list(summary = result, lrt_raw = lrt_res), out_file)
cat("------------------------------------------------------------\n")
print(result, row.names = FALSE)
cat("Saved:", out_file, "| runtime this session:",
    round(as.numeric(difftime(Sys.time(), t0, units = "hours")), 2), "hours\n")
