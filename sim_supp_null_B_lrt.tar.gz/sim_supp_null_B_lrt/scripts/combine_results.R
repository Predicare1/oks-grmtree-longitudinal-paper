################################################################################
## combine_results.R  (B rerun)
##
##   Rscript scripts/combine_results.R
##
## Output: results/B_rerun_lrt_freevar.csv
## If the original run's results are found at ../sim_supp_null/results/, the
## table also shows the original GRMTree and LRT (variance fixed) columns.
################################################################################

files <- list.files("results", pattern = "^taskB_\\d+\\.rds$", full.names = TRUE)
cat("Found", length(files), "of 16 task results\n")

tab <- do.call(rbind, lapply(files, function(f) readRDS(f)$summary))
tab <- tab[order(tab$task_id), ]

missing <- setdiff(17:32, tab$task_id)
if (length(missing) > 0) cat("Missing tasks:", paste(missing, collapse = ", "), "\n")

orig_file <- "../sim_supp_null/results/supplementary_null_results.csv"
if (file.exists(orig_file)) {
  orig <- read.csv(orig_file)
  orig <- orig[, c("task_id", "type1_grmtree", "type1_lrt")]
  names(orig)[3] <- "type1_lrt_fixedvar"
  tab <- merge(tab, orig, by = "task_id", all.x = TRUE)
  tab <- tab[order(tab$task_id),
             c("task_id", "n_items", "n", "var_t2", "type1_grmtree",
               "type1_lrt_fixedvar", "type1_lrt_freevar", "n_valid_lrt")]
}

write.csv(tab, "results/B_rerun_lrt_freevar.csv", row.names = FALSE)

cat("\n--- VARIANCE HETEROGENEITY (mu_T2 = 0) ---\n")
print(tab, row.names = FALSE)
