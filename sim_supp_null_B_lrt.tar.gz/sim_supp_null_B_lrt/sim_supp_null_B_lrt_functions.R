################################################################################
## sim_supp_null_B_lrt_functions.R
##
## Rerun of the variance-heterogeneity null conditions (tasks 17-32 of the
## supplementary null simulation), LRT only, with the T2 latent variance
## freely estimated in the constrained model.
##
## Why: in the original run, the LRT fixed Var(theta_T2) = 1. When the true
## T2 variance differs from 1, the constrained model can only absorb that
## through the discriminations, so the LRT rejects. Freeing the T2 variance
## lets the LRT absorb a change in spread the same way it already absorbs a
## change in mean.
##
## Seeds match the original run (2026 + task_id).
##
## Authors: O. I. Arimoro, T. T. Sajobi, E. Bohm, L. M. Lix
################################################################################

suppressPackageStartupMessages({
  library(mirt)
})

## ---------------------------------------------------------------------------
## Grid: same as the original supplementary simulation (tasks 1-32).
## This rerun uses tasks 17-32 only (variance heterogeneity).
## ---------------------------------------------------------------------------

get_sim_grid <- function() {
  dist_conds <- data.frame(
    condition_type = c("Mean shift", "Mean shift",
                       "Variance heterogeneity", "Variance heterogeneity"),
    mean_t2 = c(0.25, 0.50, 0.00, 0.00),
    var_t2  = c(1.00, 1.00, 0.50, 1.50)
  )
  grid <- expand.grid(n = c(200, 500, 750, 1500),
                      n_items = c(6, 12),
                      dist_row = 1:4)
  grid <- cbind(grid[, c("n_items", "n")], dist_conds[grid$dist_row, ])
  grid$rho <- 0.6
  grid$task_id <- seq_len(nrow(grid))
  rownames(grid) <- NULL
  grid
}

## ---------------------------------------------------------------------------
## Item parameters (identical at T1 and T2: null of invariance)
## ---------------------------------------------------------------------------

get_item_params <- function(n_items) {
  a12 <- c(1.2, 1.5, 1.1, 1.8, 1.3, 1.6, 1.4, 1.7, 1.2, 1.5, 1.3, 1.9)
  d12 <- matrix(c(
    2.0, 0.7, -0.7, -2.0,
    1.8, 0.5, -0.5, -1.8,
    2.2, 0.8, -0.6, -2.1,
    1.9, 0.6, -0.8, -1.9,
    2.1, 0.7, -0.5, -2.0,
    1.7, 0.4, -0.6, -1.7,
    2.0, 0.6, -0.7, -1.8,
    1.8, 0.5, -0.5, -1.9,
    2.2, 0.8, -0.6, -2.2,
    1.9, 0.6, -0.7, -1.8,
    2.0, 0.7, -0.8, -2.0,
    1.8, 0.5, -0.6, -1.7
  ), nrow = 12, ncol = 4, byrow = TRUE)
  list(a = a12[1:n_items], d = d12[1:n_items, , drop = FALSE])
}

## ---------------------------------------------------------------------------
## Correlated latent traits with configurable T2 mean and variance
## ---------------------------------------------------------------------------

generate_theta <- function(n, rho, mean_t2 = 0, var_t2 = 1) {
  sigma <- sqrt(var_t2)
  theta_t1 <- rnorm(n)
  theta_t2 <- rho * sigma * theta_t1 + sigma * sqrt(1 - rho^2) * rnorm(n) + mean_t2
  list(t1 = theta_t1, t2 = theta_t2)
}

generate_data <- function(n, n_items, rho, mean_t2, var_t2) {
  p  <- get_item_params(n_items)
  th <- generate_theta(n, rho, mean_t2, var_t2)
  r1 <- simdata(a = p$a, d = p$d, N = n, itemtype = "graded",
                Theta = matrix(th$t1, ncol = 1))
  r2 <- simdata(a = p$a, d = p$d, N = n, itemtype = "graded",
                Theta = matrix(th$t2, ncol = 1))
  list(r1 = r1, r2 = r2)
}

## ---------------------------------------------------------------------------
## LRT with T2 variance freed
##
## Constrained model: item parameters equal across time; T2 mean, T2 variance
##   and T1-T2 covariance freely estimated (T1 fixed at N(0, 1) for scale).
## Unconstrained model: all item parameters free at each time; T2 mean and
##   covariance free. The T2 variance is not freed here because, once all T2
##   item parameters are free, a change in spread is already absorbed by the
##   T2 discriminations (freeing it would add an unidentified parameter).
## ---------------------------------------------------------------------------

build_lrt_specs_freevar <- function(n_items) {
  t1 <- 1:n_items
  t2 <- (n_items + 1):(2 * n_items)
  a_con <- paste0("(", t1, ", a1, ", t2, ", a2)", collapse = ", ")
  d_con <- paste(sapply(1:4, function(k)
    paste0("(", t1, ",", t2, ", d", k, ")", collapse = ", ")), collapse = ", ")
  factors <- paste0("Theta_T1 = 1-", n_items, "\n",
                    "Theta_T2 = ", n_items + 1, "-", 2 * n_items, "\n")
  list(
    constrained = paste0(factors,
                         "COV = Theta_T1*Theta_T2, Theta_T2*Theta_T2\n",
                         "MEAN = Theta_T2\n",
                         "CONSTRAIN = ", a_con, ", ", d_con),
    unconstrained = paste0(factors,
                           "COV = Theta_T1*Theta_T2\n",
                           "MEAN = Theta_T2")
  )
}

## Returns 1 if p < 0.05 (false positive), 0 otherwise, NA on error.
fit_lrt_freevar <- function(dat, n_items, specs) {
  r1 <- dat$r1; r2 <- dat$r2
  colnames(r1) <- paste0("T1_Item", 1:n_items)
  colnames(r2) <- paste0("T2_Item", 1:n_items)
  wide <- cbind(r1, r2)

  tryCatch({
    m0 <- mirt(wide, mirt.model(specs$constrained), itemtype = "graded",
               SE = FALSE, verbose = FALSE)
    m1 <- mirt(wide, mirt.model(specs$unconstrained), itemtype = "graded",
               SE = FALSE, verbose = FALSE)
    as.numeric(anova(m0, m1)$p[2] < 0.05)
  }, error = function(e) NA_real_)
}
