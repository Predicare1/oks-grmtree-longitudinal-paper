# B rerun: LRT with free T2 variance (variance-heterogeneity null conditions)

Reruns tasks 17-32 of the supplementary null simulation, LRT only, with the
post-intervention latent variance freely estimated in the constrained model.
Same seeds and design as the original run.

| Jobs | Var(theta_T2) | Within block |
|---|---|---|
| B01-B08 | 0.5 | B01-B04: 6 items, N = 200/500/750/1500; B05-B08: 12 items |
| B09-B16 | 1.5 | same layout |

## Run on ARC

Unpack next to the original `sim_supp_null` folder (same parent directory):

    tar xzf sim_supp_null_B_lrt.tar.gz
    cd sim_supp_null_B_lrt
    mkdir -p logs results checkpoints
    bash submit_all.sh ALL

When done:

    module load R/4.4.1
    Rscript scripts/combine_results.R

Output `results/B_rerun_lrt_freevar.csv` shows GRMTree, the original LRT
(variance fixed) and the new LRT (variance free) side by side.
