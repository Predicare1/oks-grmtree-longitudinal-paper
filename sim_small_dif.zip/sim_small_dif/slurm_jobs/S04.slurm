#!/bin/bash
#SBATCH --job-name=smalldif_S04
#SBATCH --partition=cpu2019
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=16G
#SBATCH --time=7-00:00:00
#SBATCH --output=logs/smalldif_S04_%j.out
#SBATCH --error=logs/smalldif_S04_%j.err
#SBATCH --mail-type=END,FAIL
#SBATCH --mail-user=olayinka.arimoro@ucalgary.ca

echo "Job S04 (task 4) started on $(hostname) at $(date)"
module load R/4.4.1
cd $SLURM_SUBMIT_DIR
Rscript scripts/sim_small_dif_run.R 4
echo "Job S04 finished at $(date)"
