#!/bin/bash
#SBATCH --job-name=smalldif_S21
#SBATCH --partition=cpu2019
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=16G
#SBATCH --time=7-00:00:00
#SBATCH --output=logs/smalldif_S21_%j.out
#SBATCH --error=logs/smalldif_S21_%j.err
#SBATCH --mail-type=END,FAIL
#SBATCH --mail-user=olayinka.arimoro@ucalgary.ca

echo "Job S21 (task 21) started on $(hostname) at $(date)"
module load R/4.4.1
cd $SLURM_SUBMIT_DIR
Rscript scripts/sim_small_dif_run.R 21
echo "Job S21 finished at $(date)"
