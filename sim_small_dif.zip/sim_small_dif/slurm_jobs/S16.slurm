#!/bin/bash
#SBATCH --job-name=smalldif_S16
#SBATCH --partition=cpu2019
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=16G
#SBATCH --time=7-00:00:00
#SBATCH --output=logs/smalldif_S16_%j.out
#SBATCH --error=logs/smalldif_S16_%j.err
#SBATCH --mail-type=END,FAIL
#SBATCH --mail-user=olayinka.arimoro@ucalgary.ca

echo "Job S16 (task 16) started on $(hostname) at $(date)"
module load R/4.4.1
cd $SLURM_SUBMIT_DIR
Rscript scripts/sim_small_dif_run.R 16
echo "Job S16 finished at $(date)"
