# Supplementary power simulation: small non-invariance (Delta = 0.25)

Power of GRMTree and the LRT to detect small longitudinal non-invariance, with
no change in the latent trait distribution (mu_T2 = 0, Var(theta_T2) = 1).
Everything else matches the main simulation (same item parameters, DIF items,
injection, GRMTree settings with minimum node size 50 and Bonferroni, and LRT
specification). 500 replications per cell; GRMTree and LRT use the same datasets.

| Jobs | Non-invariance type | Within block |
|---|---|---|
| S01-S08 | Non-uniform (discrimination) | S01-S04: 6 items, N = 200/500/750/1500; S05-S08: 12 items |
| S09-S16 | Uniform (thresholds) | same layout |
| S17-S24 | Both | same layout |

rho = 0.6 throughout. Seed per task: 3026 + task ID.

## Run on ARC

    tar xzf sim_small_dif.tar.gz
    cd sim_small_dif
    mkdir -p logs results checkpoints
    bash submit_all.sh ALL

Jobs checkpoint every 25 reps; resubmit the same .slurm file to resume.

When done:

    module load R/4.4.1
    Rscript scripts/combine_results.R

## Run locally

From this folder: `Rscript scripts/sim_small_dif_run.R 9` (task IDs 1 to 24).
