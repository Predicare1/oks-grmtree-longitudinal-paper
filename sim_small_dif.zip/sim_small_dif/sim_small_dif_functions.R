################################################################################
## sim_small_dif_functions.R
##
## Supplementary power simulation for small-magnitude non-invariance
## (Delta = 0.25), with no change in the latent trait distribution (mu_T2 = 0,
## Var(theta_T2) = 1), so results are not affected by impact.
##
## Data generation, non-invariance injection, GRMTree settings, and LRT
## specification match the main simulation. GRMTree and the LRT are fitted to
## the same simulated datasets. Self-contained; does not depend on other scripts.
##
## Authors: O. I. Arimoro, T. T. Sajobi, E. Bohm, L. M. Lix
################################################################################

suppressPackageStartupMessages({
  library(grmtree)
  library(mirt)
})

## ---------------------------------------------------------------------------
## Grid: 24 tasks = 3 non-invariance types x 2 scale lengths x 4 sample sizes
## Delta = 0.25, rho = 0.6, mu_T2 = 0
## ---------------------------------------------------------------------------

get_sim_grid <- function() {
  grid <- expand.grid(n = c(200, 500, 750, 1500),
                      n_items = c(6, 12),
                      dif_type = c("nonuniform", "uniform", "both"),
                      stringsAsFactors = FALSE)
  grid$dif_magnitude <- 0.25
  grid$rho <- 0.6
  grid$mean_t2 <- 0
  grid$task_id <- seq_len(nrow(grid))
  grid
}

## ---------------------------------------------------------------------------
## Item parameters (same as the main simulation)
## ---------------------------------------------------------------------------

get_item_params <- function(n_items) {
  a12 <- c(1.2, 1.5, 1.1, 1.8, 1.3, 1.6, 1.4, 1.7, 1.2, 1.5, 1.3, 1.9)
  d12 <- matrix(c(
    2.0, 0.7, -0.7, -2.0,
    1.8, 0.5, -0.5, -1.8,
    2.2, 0.8, -0.6, -2.1,
    1.9, 0.6, -0.8, -1.9,
    2.1, 0.7, -0.5, -2.0,
    1.7, 0.4, -0.6, -1.7,
    2.0, 0.6, -0.7, -1.8,
    1.8, 0.5, -0.5, -1.9,
    2.2, 0.8, -0.6, -2.2,
    1.9, 0.6, -0.7, -1.8,
    2.0, 0.7, -0.8, -2.0,
    1.8, 0.5, -0.6, -1.7
  ), nrow = 12, ncol = 4, byrow = TRUE)
  dif_items <- if (n_items == 6) c(1, 3, 6) else c(1, 6, 12)
  list(a = a12[1:n_items], d = d12[1:n_items, , drop = FALSE],
       dif_items = dif_items)
}

## Non-invariance at T2: add Delta to discriminations (non-uniform), to the
## intercepts of all thresholds (uniform), or both, for the three DIF items.
## Same injection as the main simulation.
create_t2_params <- function(p, dif_type, dif_magnitude) {
  a2 <- p$a; d2 <- p$d
  for (i in p$dif_items) {
    if (dif_type %in% c("nonuniform", "both")) a2[i]  <- p$a[i]  + dif_magnitude
    if (dif_type %in% c("uniform", "both"))    d2[i, ] <- p$d[i, ] + dif_magnitude
  }
  list(a = a2, d = d2)
}

## Correlated latent traits; Var(theta_T2) = 1, Cor = rho
generate_theta <- function(n, rho, mean_t2 = 0) {
  t1 <- rnorm(n)
  t2 <- rho * t1 + sqrt(1 - rho^2) * rnorm(n) + mean_t2
  list(t1 = t1, t2 = t2)
}

generate_data <- function(cond) {
  p  <- get_item_params(cond$n_items)
  p2 <- create_t2_params(p, cond$dif_type, cond$dif_magnitude)
  th <- generate_theta(cond$n, cond$rho, cond$mean_t2)
  r1 <- simdata(a = p$a,  d = p$d,  N = cond$n, itemtype = "graded",
                Theta = matrix(th$t1, ncol = 1))
  r2 <- simdata(a = p2$a, d = p2$d, N = cond$n, itemtype = "graded",
                Theta = matrix(th$t2, ncol = 1))
  list(r1 = r1, r2 = r2)
}

## ---------------------------------------------------------------------------
## GRMTree: person-period data, time as the only covariate.
## Returns 1 if the tree splits on time, 0 otherwise, NA on error.
## ---------------------------------------------------------------------------

fit_grmtree <- function(dat, n_items, minbucket = 50) {
  item_names <- paste0("Item_", 1:n_items)
  d1 <- as.data.frame(dat$r1); names(d1) <- item_names; d1$time <- "T1"
  d2 <- as.data.frame(dat$r2); names(d2) <- item_names; d2$time <- "T2"
  df <- rbind(d1, d2)
  df$time <- factor(df$time, levels = c("T1", "T2"))
  df$resp <- as.matrix(df[, item_names])
  tryCatch({
    tree <- grmtree(resp ~ time, data = df,
                    control = grmtree.control(minbucket = minbucket,
                                              p_adjust = "bonferroni",
                                              alpha = 0.05))
    as.numeric(length(nodeids(tree, terminal = TRUE)) > 1)
  }, error = function(e) NA_real_)
}

## ---------------------------------------------------------------------------
## LRT: two-factor longitudinal GRM, as in the main simulation (T2 mean and
## T1-T2 covariance free; T2 variance = 1, matching the data generation).
## Returns 1 if p < 0.05, 0 otherwise, NA on error.
## ---------------------------------------------------------------------------

build_lrt_specs <- function(n_items) {
  t1 <- 1:n_items; t2 <- (n_items + 1):(2 * n_items)
  a_con <- paste0("(", t1, ", a1, ", t2, ", a2)", collapse = ", ")
  d_con <- paste(sapply(1:4, function(k)
    paste0("(", t1, ",", t2, ", d", k, ")", collapse = ", ")), collapse = ", ")
  base <- paste0("Theta_T1 = 1-", n_items, "\n",
                 "Theta_T2 = ", n_items + 1, "-", 2 * n_items, "\n",
                 "COV = Theta_T1*Theta_T2\n",
                 "MEAN = Theta_T2")
  list(constrained   = paste0(base, "\nCONSTRAIN = ", a_con, ", ", d_con),
       unconstrained = base)
}

fit_lrt <- function(dat, n_items, specs) {
  r1 <- dat$r1; r2 <- dat$r2
  colnames(r1) <- paste0("T1_Item", 1:n_items)
  colnames(r2) <- paste0("T2_Item", 1:n_items)
  wide <- cbind(r1, r2)
  tryCatch({
    m0 <- mirt(wide, mirt.model(specs$constrained), itemtype = "graded",
               SE = FALSE, verbose = FALSE)
    m1 <- mirt(wide, mirt.model(specs$unconstrained), itemtype = "graded",
               SE = FALSE, verbose = FALSE)
    as.numeric(anova(m0, m1)$p[2] < 0.05)
  }, error = function(e) NA_real_)
}
