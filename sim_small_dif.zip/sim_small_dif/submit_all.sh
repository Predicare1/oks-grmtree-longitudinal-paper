#!/bin/bash
# Usage: bash submit_all.sh ALL | NU | U | B
#   NU = non-uniform (S01-S08), U = uniform (S09-S16), B = both (S17-S24)
GROUP=${1:-ALL}
mkdir -p logs results checkpoints

case $GROUP in
  NU)  FILES=$(ls slurm_jobs/S0[1-8].slurm) ;;
  U)   FILES=$(ls slurm_jobs/S09.slurm slurm_jobs/S1[0-6].slurm) ;;
  B)   FILES=$(ls slurm_jobs/S1[7-9].slurm slurm_jobs/S2[0-4].slurm) ;;
  ALL) FILES=$(ls slurm_jobs/*.slurm) ;;
  *)   echo "Usage: bash submit_all.sh ALL | NU | U | B"; exit 1 ;;
esac

for f in $FILES; do
  echo "Submitting $f"
  sbatch "$f"
done
echo "Done. Check with: squeue -u \$USER"
