################################################################################
## combine_results.R
##
##   Rscript scripts/combine_results.R
##
## Output: results/small_dif_results.csv (long) and a printed table in the
## layout used in the response letter (rows: type x N; columns: 6 and 12 items).
################################################################################

files <- list.files("results", pattern = "^task_\\d+\\.rds$", full.names = TRUE)
cat("Found", length(files), "of 24 task results\n")

tab <- do.call(rbind, lapply(files, function(f) readRDS(f)$summary))
tab <- tab[order(tab$task_id), ]

missing <- setdiff(1:24, tab$task_id)
if (length(missing) > 0) cat("Missing tasks:", paste(missing, collapse = ", "), "\n")

write.csv(tab, "results/small_dif_results.csv", row.names = FALSE)

wide <- reshape(tab[, c("dif_type", "n", "n_items", "power_grmtree", "power_lrt")],
                idvar = c("dif_type", "n"), timevar = "n_items", direction = "wide")
names(wide) <- sub("power_grmtree\\.(\\d+)", "GRMTree_\\1items", names(wide))
names(wide) <- sub("power_lrt\\.(\\d+)",     "LRT_\\1items",     names(wide))
wide$dif_type <- factor(wide$dif_type, levels = c("nonuniform", "uniform", "both"),
                        labels = c("Non-uniform", "Uniform", "Both"))
wide <- wide[order(wide$dif_type, wide$n),
             c("dif_type", "n", "GRMTree_6items", "LRT_6items",
               "GRMTree_12items", "LRT_12items")]

cat("\nPower (%) for small non-invariance (Delta = 0.25), rho = 0.6, mu_T2 = 0\n")
print(wide, row.names = FALSE)
